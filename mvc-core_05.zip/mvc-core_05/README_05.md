# MVC-Core version 05
![Logo UCA - IUT|](images/Logo_IUT-icon.png)
## Introduction
```
$ rsync -auv mvc-core_04/ mvc-core_05/
$ cd mvc-core_05/
$ git commit -a -m 'version 05'
```
## Mode développement et production

> Création de 2 fichiers de configurations spécifiques :
* Config.dev.php
* Config.prod.php

## Mise en place d'une classe « Template »
L'objectif est de 
