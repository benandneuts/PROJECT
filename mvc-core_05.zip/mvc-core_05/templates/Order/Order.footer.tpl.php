		<!--  Order footer begin -->
		<hr />
		<h3>My Order footer goes here !</h3>
		<hr />
		<!--  Order footer end -->
	
