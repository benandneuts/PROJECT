## Admin templates go inside this directory
