		<!-- End div container -->
		</div>
		<footer>
			My Common footer goes here !
			<p>© 2020 JM BRUNEAU - UCA - IUT - INFO</p>
		</footer>
	</body>
</html>