<?php
namespace mvcCore\Views;

class OrderCreateView extends View {
	
	use OrderView;
	
}
