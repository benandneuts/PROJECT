<?php
namespace mvcCore\Views;

class OrderDeleteView extends View {
	
	use OrderView;
	
}
