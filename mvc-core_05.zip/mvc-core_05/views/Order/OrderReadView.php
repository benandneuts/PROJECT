<?php
namespace mvcCore\Views;

class OrderReadView extends View {
	
	use OrderView;
	
}
