<?php
namespace mvcCore\Views;

class OrderUpdateView extends View {
	
	use OrderView;
	
}
